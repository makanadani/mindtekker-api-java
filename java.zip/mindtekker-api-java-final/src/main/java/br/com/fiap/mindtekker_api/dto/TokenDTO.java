package br.com.fiap.mindtekker_api.dto;

public record TokenDTO(String token) {
}
